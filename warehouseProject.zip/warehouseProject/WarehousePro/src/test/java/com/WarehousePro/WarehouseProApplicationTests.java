package com.WarehousePro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseProApplicationTests {

	@Test
	void contextLoads() {
	}

}
